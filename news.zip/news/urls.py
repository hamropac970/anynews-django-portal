from django.urls import path
from .views import *

urlpatterns = [
    path("", index, name="home"),
    path("contact/", contact, name="contact"),
    path("likes/", likes, name="likes"),
    path("likes/<int:pk>/", user_like, name="like"),
    path("category/<int:pk>/", category, name="category"),
    path("products/<int:pk>/", detail, name="detail"),
    path("signup/", SignUp.as_view(), name="signup"),
    # path("signup/", signup, name="signup"),
    path("signin/", SignIn.as_view(), name="signin"),
    # path("signin/", signin, name="signin"),
    path("signout/", SignOut.as_view(), name="signout"),
    # path("signout/", signout, name="signout"),
]