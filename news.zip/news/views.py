from django.contrib.auth import login, logout
from django.core.paginator import Paginator
from django.db.models import Min, Q
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView
from django.contrib.auth.views import LoginView, LogoutView
from shop.forms import SignUpForm, SignInForm
from shop.models import *


# Create your views here.
def index(request):
    categories = Category.objects.all()
    subcategories = SubCategory.objects.all()
    offers = Offer.objects.all()
    brands = Brand.objects.all()
    products = Product.objects.all()
    context = {
        "categories":categories,
        "subcategories":subcategories,
        "offers":offers,
        "brands":brands,
        "featured_products":products[:8],
        "recent_products":products.order_by('-id')[:8],
    }
    return render(request, "shop/index.html",context)

def contact(request):
    if request.method == "POST":
        full_name = request.POST.get("full_name")
        email = request.POST.get("email")
        subject = request.POST.get("subject")
        message = request.POST.get("message")
        Contact.objects.create(full_name=full_name,email=email,subject=subject,message=message)
    return render(request, "shop/contact.html")

def category(request,pk):
    cat = Category.objects.get(pk=pk)
    products = Product.objects.filter(category=cat)
    sort_fields = request.GET.get("sort")
    color_fields = request.GET.getlist("color")
    size_fields = request.GET.getlist("size")
    price_fields = request.GET.getlist("price")
    if sort_fields:
        products = products.annotate(price=Min("types__price")).order_by(sort_fields)
    if color_fields:
        products = products.filter(types__color__in=color_fields)
    if size_fields:
        products = products.filter(types__size__in=size_fields)
    if price_fields:
        price_list = {
            "0-100":(0,100),
            "100-200":(100,200),
            "200-300":(200,300),
            "300-400":(300,400),
            "400-500":(400,500),
        }
        query = Q()
        for key in price_fields:
            if key in price_list:
                low,high = price_list[key]
                query |= Q(types__price__gte=low,types__price__lte=high)
        if query:
            products = products.filter(query).distinct()
    paginator = Paginator(products,9)
    page_number = request.GET.get("page")
    page_list = paginator.get_page(page_number)
    context = {
        "products":page_list
    }
    return render(request,"shop/category.html", context)

def detail(request, pk):
    products = Product.objects.all()
    data = []
    while len(data) < 5:
        from random import randint
        num = randint(1, len(products) - 1)
        if not products[num] in data:
            data.append(products[num])
    context = {
        "product": Product.objects.get(pk=pk),
        "products": data
    }
    return render(request, "shop/detail.html", context)

def likes(request):
    products = Product.objects.all()
    context = {
        "products":products
    }
    return render(request, "shop/likes.html", context)

def user_like(request,pk):
    user = request.user if request.user.is_authenticated else None
    product = Product.objects.get(pk=pk)
    if product:
        liked_products = Like.objects.filter(user=user)
        if product in [item.product for item in liked_products]:
            like_product = Like.objects.filter(user=user,product=product)
            like_product.delete()
        else:
            Like.objects.create(user=user,product=product)
    next_page = request.META.get("HTTP_REFERER","home")
    return redirect(next_page)


# def signup(request):
#     form = SignUpForm(data=request.POST or None)
#     if request.method == "POST":
#         if form.is_valid():
#             user = form.save()
#             return redirect("signin")
#     context = {
#         "form":form
#     }
#     return render(request, "shop/signup.html", context)
class SignUp(CreateView):
    template_name = "shop/signup.html"
    form_class = SignUpForm
    success_url = reverse_lazy("signin")

    def form_valid(self, form):
        user = form.save()
        return super().form_valid(form)

# def signin(request):
#     form = SignInForm(data=request.POST or None)
#     if request.method == "POST":
#         if form.is_valid():
#             user = form.get_user()
#             login(request, user)
#             return redirect("home")
#     context = {
#         "form": form
#     }
#     return render(request, "shop/signin.html", context)
class SignIn(LoginView):
    template_name = "shop/signin.html"
    authentication_form = SignInForm
    def get_success_url(self):
        return reverse_lazy("home")

# def signout(request):
#     logout(request)
#     return redirect("signin")
class SignOut(LogoutView):
    next_page = reverse_lazy("signin")

